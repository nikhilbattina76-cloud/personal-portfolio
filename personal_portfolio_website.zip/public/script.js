fetch("/api/projects")
.then(r=>r.json())
.then(data=>{
document.getElementById("projects").innerHTML=
data.map(p=>`<h3>${p.title}</h3><p>${p.description}</p><hr>`).join("");
});