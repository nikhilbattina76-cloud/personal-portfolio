const express=require("express");
const mongoose=require("mongoose");
const cors=require("cors");
const app=express();

app.use(cors());
app.use(express.json());
app.use(express.static("public"));

mongoose.connect("mongodb://127.0.0.1:27017/portfolio");

const ProjectSchema=new mongoose.Schema({
  title:String,
  description:String,
  tech:String
});

const Project=mongoose.model("Project",ProjectSchema);

app.get("/api/projects",async(req,res)=>{
  res.json(await Project.find());
});

app.post("/api/projects",async(req,res)=>{
  const p=new Project(req.body);
  await p.save();
  res.json(p);
});

app.listen(3000,()=>console.log("Running on port 3000"));
